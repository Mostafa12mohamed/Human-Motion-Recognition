"""
Main function of segmenting raw data sequence using sliding windows. Create segmented data for further training and testing.
"""

# Author: Shuo Li
# Date: 2025/01/12

import os
import tqdm
import warnings
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import util_data
from sklearn.ensemble import RandomForestClassifier

def main_task(Params):
    """
    Parameters 
    ----------
    Params: The pre-defined class of parameter settings.

    Returns
    -------

    """


    ## Step 1. Data segmentation of IMU signals.
    # load data.
    GT = util_data.GroundTruth(Params=Params)
    # Load the ID info csv.
    info_raw = pd.read_csv(Params.dir_info)
    # Initialize dataframe.
    df_seg = pd.DataFrame(columns=['ID', 'condition', 'num_seq', 'age', 'gender'])  # Subject information.
    df_seg = pd.concat((df_seg, 
                        pd.DataFrame(columns=['gyro_x_'+str(i_f) for i_f in range(0, Params.len_segment)], index=[0]),  # Gyroscope x-axis.
                        pd.DataFrame(columns=['gyro_y_'+str(i_f) for i_f in range(0, Params.len_segment)], index=[0]),  # Gyroscope y-axis.
                        pd.DataFrame(columns=['gyro_z_'+str(i_f) for i_f in range(0, Params.len_segment)], index=[0]),  # Gyroscope z-axis.
                        pd.DataFrame(columns=['acc_x_'+str(i_f) for i_f in range(0, Params.len_segment)], index=[0]),  # Accelerometer x-axis.
                        pd.DataFrame(columns=['acc_y_'+str(i_f) for i_f in range(0, Params.len_segment)], index=[0]),  # Accelerometer y-axis.
                        pd.DataFrame(columns=['acc_z_'+str(i_f) for i_f in range(0, Params.len_segment)], index=[0])  # Accelerometer z-axis.
                        ), ignore_index=True)
    df_seg.drop(df_seg.index, inplace=True)
    # Collect all segmented data.
    # Loop over walk-1 and walk-2.
    for condition in [0, 1]:
        print('Segmenting Walk-'+str(condition+1)+' IMU signals.')
        # Loop over all subjects.
        for ID in tqdm.tqdm(info_raw['ID']):
            # Collect IMU data and groundtruth.
            gyro_x, gyro_y, gyro_z, acc_x, acc_y, acc_z, age, gender = GT.get_GT(specification=[condition, ID])
            num_seq = 0
            if np.isnan(gyro_x).all():  # No accessible data.
                continue
            else:
                while len(gyro_x) >= Params.len_segment:
                    # Current data collection.
                    df_tmp = pd.DataFrame(columns=df_seg.columns.values.tolist())
                    # Segementation using a sliding window of [Params.len_segment] samples.
                    df_tmp.loc[0, ['gyro_x_'+str(i_f) for i_f in range(0, Params.len_segment)]] = gyro_x[:Params.len_segment]
                    df_tmp.loc[0, ['gyro_y_'+str(i_f) for i_f in range(0, Params.len_segment)]] = gyro_y[:Params.len_segment]
                    df_tmp.loc[0, ['gyro_z_'+str(i_f) for i_f in range(0, Params.len_segment)]] = gyro_z[:Params.len_segment]
                    df_tmp.loc[0, ['acc_x_'+str(i_f) for i_f in range(0, Params.len_segment)]] = acc_x[:Params.len_segment]
                    df_tmp.loc[0, ['acc_y_'+str(i_f) for i_f in range(0, Params.len_segment)]] = acc_y[:Params.len_segment]
                    df_tmp.loc[0, ['acc_z_'+str(i_f) for i_f in range(0, Params.len_segment)]] = acc_z[:Params.len_segment]
                    # Move the sliding window.
                    gyro_x = gyro_x[Params.len_slide:]
                    gyro_y = gyro_y[Params.len_slide:]
                    gyro_z = gyro_z[Params.len_slide:]
                    acc_x = acc_x[Params.len_slide:]
                    acc_y = acc_y[Params.len_slide:]
                    acc_z = acc_z[Params.len_slide:]
                    # Save processed data.
                    df_tmp.loc[0, ['ID', 'condition', 'num_seq', 'age', 'gender']] = [ID, condition, num_seq, age, gender]
                    df_seg = pd.concat((df_seg, df_tmp), ignore_index=True)
                    # Next window.
                    num_seq = num_seq + 1
    # Save dataframe.
    dir_save = os.path.join(dir_crt, 'data', 'data_segmented.csv')
    df_seg.to_csv(dir_save, index=None)
    print('Segmented IMU data has been saved in '+dir_save+'.')


    ## Step 2. Visualize a sample IMU signal.
    dir_save = os.path.join(dir_crt, 'data', 'data_segmented.csv')
    df_seg = pd.read_csv(dir_save, index_col=None)
    ID_sample = int(df_seg.loc[0, ['ID']].values[0])
    data_gyro_x = df_seg.loc[0, ['gyro_x_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Gyroscope x-axis.
    data_gyro_y = df_seg.loc[0, ['gyro_y_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Gyroscope y-axis.
    data_gyro_z = df_seg.loc[0, ['gyro_z_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Gyroscope z-axis.
    data_acc_x = df_seg.loc[0, ['acc_x_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Accelerometer x-axis.
    data_acc_y = df_seg.loc[0, ['acc_y_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Accelerometer y-axis.
    data_acc_z = df_seg.loc[0, ['acc_z_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Accelerometer z-axis.
    # Sample IMU data visualization.
    plt.subplot(211)
    plt.plot(data_gyro_x, c='red')
    plt.plot(data_gyro_y, c='green')
    plt.plot(data_gyro_z, c='blue')
    plt.legend(['X-axis', 'Y-axis', 'Z-axis'])
    plt.title('Gyroscope Data. Subject ID: ' + str(ID_sample)+'.')
    plt.subplot(212)
    plt.plot(data_acc_x, c='red')
    plt.plot(data_acc_y, c='green')
    plt.plot(data_acc_z, c='blue')
    plt.legend(['X-axis', 'Y-axis', 'Z-axis'])
    plt.title('Accelerometer Data. Subject ID: ' + str(ID_sample)+'.')
    plt.show()


    ## Step 3. Hand-crafted feature extraction from IMU signals.
    # Loop over all data segments.
    print('Extracting hand-crafted feature from IMU signals.')
    for i_seg in tqdm.tqdm(range(0, len(df_seg))):
        # Load segmented data.
        df_data = df_seg.loc[i_seg, :].copy()
        # Load ID, age, and gender information.
        ID = int(df_data['ID'])
        condition = int(df_data['condition'])
        num_seq = int(df_data['num_seq'])
        age = int(df_data['age'])
        gender = int(df_data['gender'])
        # Collect IMU data.
        data_gyro_x = df_data[['gyro_x_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Gyroscope x-axis.
        data_gyro_y = df_data[['gyro_y_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Gyroscope y-axis.
        data_gyro_z = df_data[['gyro_z_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Gyroscope z-axis.
        data_acc_x = df_data[['acc_x_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Accelerometer x-axis.
        data_acc_y = df_data[['acc_y_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Accelerometer y-axis.
        data_acc_z = df_data[['acc_z_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Accelerometer z-axis.
        data_imu = np.row_stack((data_gyro_x, data_gyro_y, data_gyro_z, data_acc_x, data_acc_y, data_acc_z))  # IMU data.
        # Extract manually designed features.
        feature_handcrafted = util_data.IMU2ManualFeature(data_imu)
        feature_handcrafted = pd.concat((pd.Series({'ID': ID, 'condition': condition, 'num_seq': num_seq, 'age': age, 'gender': gender}), 
                                    feature_handcrafted))
        if i_seg == 0:
            # Create new dataframe to save data.
            df_feature_handcrafted = feature_handcrafted.to_frame().T
        else:
            df_feature_handcrafted = pd.concat((df_feature_handcrafted, feature_handcrafted.to_frame().T), ignore_index=True)
    # Save extracted features.
    dir_save = os.path.join(dir_crt, 'data', 'data_feature_handcrafted.csv')
    df_feature_handcrafted.to_csv(dir_save, index=None)


    ## Step 4. Autocorrelation feature extraction from IMU signals.
    dir_save = os.path.join(dir_crt, 'data', 'data_segmented.csv')
    df_seg = pd.read_csv(dir_save, index_col=None)
    # Loop over all data segments.
    print('Extracting correlation feature from IMU signals.')
    for i_seg in tqdm.tqdm(range(0, len(df_seg))):
        # Load segmented data.
        df_data = df_seg.loc[i_seg, :].copy()
        # Load ID, age, and gender information.
        ID = int(df_data['ID'])
        condition = int(df_data['condition'])
        num_seq = int(df_data['num_seq'])
        age = int(df_data['age'])
        gender = int(df_data['gender'])
        # Collect IMU data.
        data_gyro_x = df_data[['gyro_x_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Gyroscope x-axis.
        data_gyro_y = df_data[['gyro_y_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Gyroscope y-axis.
        data_gyro_z = df_data[['gyro_z_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Gyroscope z-axis.
        data_acc_x = df_data[['acc_x_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Accelerometer x-axis.
        data_acc_y = df_data[['acc_y_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Accelerometer y-axis.
        data_acc_z = df_data[['acc_z_'+str(i_f) for i_f in range(0, Params.len_segment)]].values  # Accelerometer z-axis.
        data_imu = np.row_stack((data_gyro_x, data_gyro_y, data_gyro_z, data_acc_x, data_acc_y, data_acc_z))  # IMU data.
        # Extract manually designed features.
        feature_autocorr = util_data.IMU2AutoCorrFeature(data_imu)
        feature_autocorr = pd.concat((pd.Series({'ID': ID, 'condition': condition, 'num_seq': num_seq, 'age': age, 'gender': gender}), 
                                      feature_autocorr))
        if i_seg == 0:
            # Create new dataframe to save data.
            df_feature_autocorr = feature_autocorr.to_frame().T
        else:
            df_feature_autocorr = pd.concat((df_feature_autocorr, feature_autocorr.to_frame().T), ignore_index=True)
    # Save extracted features.
    dir_save = os.path.join(dir_crt, 'data', 'data_feature_autocorrelation.csv')
    df_feature_autocorr.to_csv(dir_save, index=None)


    ## Step 5. Visualization of age and gender distribution. 
    list_num_female = []  # Number of female subjects of certain age groups.
    list_num_male = []  # Number of male subjects of certain age groups.
    for i_range in range(0, len(Params.range_age)-1):
        age_low = Params.range_age[i_range]
        age_high = Params.range_age[i_range+1]
        list_num_female.append(len(df_seg.loc[(df_seg['gender'].values==0) & 
                                          (df_seg['age'].values>=age_low) & 
                                          (df_seg['age'].values<age_high), :]))
        list_num_male.append(len(df_seg.loc[(df_seg['gender'].values==1) & 
                                          (df_seg['age'].values>=age_low) & 
                                          (df_seg['age'].values<age_high), :]))
    list_num_female = np.array(list_num_female)
    list_num_male = np.array(list_num_male)
    plt.barh(range(len(list_num_female)), list_num_female)
    plt.barh(range(len(list_num_male)), -list_num_male)
    plt.xlim(-350, 350)
    plt.xticks(range(-300, 400, 100), labels=[300, 200, 100, 0, 100, 200, 300])
    plt.yticks(range(0, 5), labels=['0-10', '10-18', '18-36', '36-45', '≥45'])
    plt.legend(['Female', 'Male'])
    plt.title('Gender distribution across different age groups.')
    plt.show()


    ## Step 6. Gender Classification on a balanced dataset.
    # N-fold cross-validation.
    list_idx_split = util_data.split_balance(list_idx=df_seg.index.values.tolist(), 
                                             list_age=df_seg['age'].values.tolist(), 
                                             list_gender=df_seg['gender'].values.tolist(), 
                                             range_age=Params.range_age, 
                                             num_fold=Params.num_fold, 
                                             ratio_female_male=[1, 1], 
                                             seed=Params.seed)
    
    # Gender classification based on the original IMU signals.
    df_seg = df_seg.drop(['ID', 'condition', 'num_seq', 'age'], axis=1)
    print('Training random forest classifier based on IMU signals.')
    list_acc_test = []
    for fold_tmp in tqdm.tqdm(range(0, Params.num_fold)):
        # Train-test split.
        df_seg_train = pd.DataFrame(columns=df_seg.columns)
        for i_fold in range(0, len(list_idx_split)):
            if i_fold == fold_tmp:
                continue
            else:
                df_seg_train = pd.concat([df_seg_train, df_seg.loc[list_idx_split[i_fold], :]])
            df_seg_test = df_seg.loc[list_idx_split[fold_tmp], :]
        # Start training the ML model.
        X_train = df_seg_train.drop('gender', axis=1).values
        Y_train_target = df_seg_train['gender'].values.astype(np.int8)
        X_test = df_seg_test.drop('gender', axis=1).values
        Y_test_target = df_seg_test['gender'].values.astype(np.int8)
        # Fit model.
        clf = RandomForestClassifier()
        clf.fit(X_train, Y_train_target)
        # Model evaluation.
        Y_train_pred = clf.predict(X_train)
        Y_test_pred = clf.predict(X_test)
        # Record training history.
        list_acc_test.append(np.mean(np.array(Y_test_target).ravel() == np.array(Y_test_pred).ravel()).item())
    print('The average gender classification accuracy based on IMU signals is: '+str(np.mean(list_acc_test)))
    
    # Gender classification based on hand-crafted features.
    df_feature_handcrafted_copy = df_feature_handcrafted.drop(['ID', 'condition', 'num_seq', 'age'], axis=1)
    print('Training random forest classifier based on hand-crafted features.')
    list_acc_test = []
    for fold_tmp in tqdm.tqdm(range(0, Params.num_fold)):
        # Train-test split.
        df_feature_handcrafted_train = pd.DataFrame(columns=df_feature_handcrafted_copy.columns)
        for i_fold in range(0, len(list_idx_split)):
            if i_fold == fold_tmp:
                continue
            else:
                df_feature_handcrafted_train = pd.concat([df_feature_handcrafted_train, df_feature_handcrafted_copy.loc[list_idx_split[i_fold], :]])
            df_feature_handcrafted_test = df_feature_handcrafted_copy.loc[list_idx_split[fold_tmp], :]
        # Start training the ML model.
        X_train = df_feature_handcrafted_train.drop('gender', axis=1).values
        Y_train_target = df_feature_handcrafted_train['gender'].values.astype(np.int8)
        X_test = df_feature_handcrafted_test.drop('gender', axis=1).values
        Y_test_target = df_feature_handcrafted_test['gender'].values.astype(np.int8)
        # Fit model.
        clf = RandomForestClassifier()
        clf.fit(X_train, Y_train_target)
        # Model evaluation.
        Y_train_pred = clf.predict(X_train)
        Y_test_pred = clf.predict(X_test)
        # Record training history.
        list_acc_test.append(np.mean(np.array(Y_test_target).ravel() == np.array(Y_test_pred).ravel()).item())
    print('The average gender classification accuracy based on hand-crafted feature is: '+str(np.mean(list_acc_test)))
    
    # Gender classification based on hand-crafted features.
    df_feature_autocorr_copy = df_feature_autocorr.drop(['ID', 'condition', 'num_seq', 'age'], axis=1)
    print('Training random forest classifier based on autocorrelation features.')
    list_acc_test = []
    for fold_tmp in tqdm.tqdm(range(0, Params.num_fold)):
        # Train-test split.
        df_feature_autocorr_train = pd.DataFrame(columns=df_feature_autocorr_copy.columns)
        for i_fold in range(0, len(list_idx_split)):
            if i_fold == fold_tmp:
                continue
            else:
                df_feature_autocorr_train = pd.concat([df_feature_autocorr_train, df_feature_autocorr_copy.loc[list_idx_split[i_fold], :]])
            df_feature_autocorr_test = df_feature_autocorr_copy.loc[list_idx_split[fold_tmp], :]
        # Start training the ML model.
        X_train = df_feature_autocorr_train.drop('gender', axis=1).values
        Y_train_target = df_feature_autocorr_train['gender'].values.astype(np.int8)
        X_test = df_feature_autocorr_test.drop('gender', axis=1).values
        Y_test_target = df_feature_autocorr_test['gender'].values.astype(np.int8)
        # Fit model.
        clf = RandomForestClassifier()
        clf.fit(X_train, Y_train_target)
        # Model evaluation.
        Y_train_pred = clf.predict(X_train)
        Y_test_pred = clf.predict(X_test)
        # Record training history.
        list_acc_test.append(np.mean(np.array(Y_test_target).ravel() == np.array(Y_test_pred).ravel()).item())
    print('The average gender classification accuracy based on autocorrelation feature is: '+str(np.mean(list_acc_test)))
    
    # Gender classification based on combined features (hand-crafted + autocorrelation).
    df_feature_combined = pd.DataFrame([])
    df_feature_tmp = pd.concat([df_feature_handcrafted.drop(list(set(df_feature_handcrafted.columns) & 
                                                                 set(df_feature_autocorr.columns)), axis=1), 
                                df_feature_autocorr], axis=1)
    df_feature_combined = pd.concat((df_feature_combined, df_feature_tmp), ignore_index=True)  
    df_feature_combined = df_feature_combined.drop(['ID', 'condition', 'num_seq', 'age'], axis=1)
    print('Training random forest classifier based on combined features.')
    list_acc_test = []
    for fold_tmp in tqdm.tqdm(range(0, Params.num_fold)):
        # Train-test split.
        df_feature_combined_train = pd.DataFrame(columns=df_feature_combined.columns)
        for i_fold in range(0, len(list_idx_split)):
            if i_fold == fold_tmp:
                continue
            else:
                df_feature_combined_train = pd.concat([df_feature_combined_train, df_feature_combined.loc[list_idx_split[i_fold], :]])
            df_feature_combined_test = df_feature_combined.loc[list_idx_split[fold_tmp], :]
        # Start training the ML model.
        X_train = df_feature_combined_train.drop('gender', axis=1).values
        Y_train_target = df_feature_combined_train['gender'].values.astype(np.int8)
        X_test = df_feature_combined_test.drop('gender', axis=1).values
        Y_test_target = df_feature_combined_test['gender'].values.astype(np.int8)
        # Fit model.
        clf = RandomForestClassifier()
        clf.fit(X_train, Y_train_target)
        # Model evaluation.
        Y_train_pred = clf.predict(X_train)
        Y_test_pred = clf.predict(X_test)
        # Record training history.
        list_acc_test.append(np.mean(np.array(Y_test_target).ravel() == np.array(Y_test_pred).ravel()).item())
    print('The average gender classification accuracy based on combined feature is: '+str(np.mean(list_acc_test)))



if __name__ == "__main__":
    dir_crt = os.getcwd()  # Get current directory.
    dir_option = os.path.join(dir_crt, 'code', 'options.yaml')  # Directory of experiment parameters.
    name_dataset = 'OU_ISIR_Inertial_Sensor'
    Params = util_data.Params(dir_option, name_dataset)  # Construct parameter object.
    dir_dataset = os.path.join(dir_crt, 'data', 'IMU_original')  # Directory of dataset.
    Params.dir_dataset = dir_dataset
    dir_info = os.path.join(dir_crt, 'IDGenderAgelist.csv')  # Directory of demographic information list.
    Params.dir_info = dir_info
    main_task(Params=Params)